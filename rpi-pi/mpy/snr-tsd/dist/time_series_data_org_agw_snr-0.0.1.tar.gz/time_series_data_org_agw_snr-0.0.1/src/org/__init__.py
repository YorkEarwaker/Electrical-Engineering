# print(f'invoking __init__.py form {__name__}')
# import snr.snr_bme280_dvr
#
# __version__ = "0.1.0"
# __author__ = "York Earwaker"
# 
# print(f'sensor package v{__version__} initialised.')