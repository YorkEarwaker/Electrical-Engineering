
# https://thepihut.com/blogs/raspberry-pi-tutorials/raspberry-pi-pico-getting-started-guide
# Hello World

print("This is my Pico talking!")
print("Hello World!")
print("Duck Soup")
print("A Night At The Opera")