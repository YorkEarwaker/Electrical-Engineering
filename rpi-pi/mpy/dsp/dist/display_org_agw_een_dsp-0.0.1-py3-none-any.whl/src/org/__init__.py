# print(f'invoking __init__.py form {__name__}')
#
# __version__ = "0.1.0"
# __author__ = "Citizen Developer"
# 
# print(f'sensor package v{__version__} initialised.')